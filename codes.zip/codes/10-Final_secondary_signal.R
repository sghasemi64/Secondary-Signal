#install.packages("data.table")
library(data.table)

dispersion=3  # used to be 1 until now
ignoreR2=1 # if 1, ignore r2 for eucledian distance
GI=0 #if 1, |r^2-0.3|

#MERGE-interSNPS is the merge intersnps results.
#MERGE-GCTA is the merge GCTA results.
interSNPs <- fread("MERGE-interSNPS", data.table=F)
GCTA <- fread("MERGE-GCTA", data.table=F)
interSNPs <- interSNPs[,c(1:8,17,18)]
names(interSNPs) <- c("chr","rs1","minorallele1","majorallele1","rs2","minorallele2","majorallele2","D","Dprime","R2")




if (GI==1){
  interSNPs$R2[which(interSNPs$R2==0.3000)]<-0.3001 ; interSNPs$labsR2 <- log(abs(interSNPs$R2-0.3))
} else {
  interSNPs$labsR2 <- log(abs(interSNPs$R2))
  }
interSNPs$D[which(interSNPs$D==0.0000)]<- 0.0001
interSNPs$labsD <- log(abs(interSNPs$D))
interSNPs$normal_R2 <- (interSNPs$labsR2-mean(interSNPs$labsR2))/sd(interSNPs$labsR2)
interSNPs$normal_D <- (interSNPs$labsD-mean(interSNPs$labsD))/sd(interSNPs$labsD)
min_D1<-min(interSNPs$normal_D)
min_R21<-min(interSNPs$normal_R2)
#center point
min_D2<-(log(1)-mean(interSNPs$labsD))/sd(interSNPs$labsD)
min_R22<-(log(0.0001)-mean(interSNPs$labsR2))/sd(interSNPs$labsR2)
interSNPs$Euclidean_d <- sqrt((interSNPs$normal_R2-(min(min_R21,min_R22)))^2+(interSNPs$normal_D-(min(min_D1,min_D2)))^2)
if (ignoreR2==1){interSNPs$Euclidean_d <- sqrt(0+(interSNPs$normal_D-(min(min_D1,min_D2)))^2)}


###########################################################################################################################
merge <- merge(interSNPs,GCTA,by.x ="rs2",by.y= "SNP")
#Top22.txt is a file contain index SNPs in first column

SNPs <- read.table("Top22.txt", sep="\t", as.is=T, comment.char="")


#sum gives you the total number of SNPs within the index SNP regions


for(i in 1:dim(SNPs)[1]){
eval(parse(text=paste0("SNPs[",i,",2] =length(merge [merge $rs1==SNPs[",i,",1],'rs1'])")))
}

Sum <- sum(SNPs[,2])
################################################################################################################################
# for 5.00E-08
Established.Threshold2 <- 5.00E-08
Bonferroni.alpha2 <-0.05/Sum
Used.Alpha2 <- Established.Threshold2*Sum
Free.Alpha2 <- 0.05-Used.Alpha2

rm <-Free.Alpha2
merge$reverse <- 1/(merge$Euclidean_d/sum(merge$Euclidean_d))
merge$reverse <- (merge$reverse)^dispersion
merge$Alpha.threshold2 <- ((merge$reverse/sum(merge$reverse)))*rm
merge$Alpha.threshold.final2 <- merge$Alpha.threshold2+ Established.Threshold2

merge$pC <- as.numeric(merge$pC)
last.result <- merge[merge$pC < merge$Alpha.threshold.final2,]
last.result2 <- last.result[!is.na(last.result$pC),]

###################################################################################################
secondarysignal <- matrix(rep(NA,length(unique(last.result2[,"rs1"]))*dim(last.result2)[2]),length(unique(last.result2[,"rs1"])),dim(last.result2)[2])
colnames(secondarysignal) <- colnames(last.result2)
rownames(secondarysignal) <- c(unique(last.result2[,"rs1"]))
secondarysignal <- as.data.frame(secondarysignal)

for (i in unique(last.result2[,"rs1"])){
  A <- last.result2[which(last.result2[,"rs1"]==i),]
  secondarysignal[i,]<-A[which(A[,"pC"]==min(A[,"pC"])),]
  #eval(parse(text=paste0("secondarysignal[",i,",] <- A[which(A[,'pC']==min(A[,'pC'])),]")))
}

secondary_signal <- secondarysignal[order(secondarysignal$chr),c(2,1,3,8,10,27,30)]
write.table(secondary_signal,"secondary_signal.txt", row.names=F, sep="\t", quote=F)


### get index SNPs with a conditional P smaller than established 5.00E-08 
helper2<-subset(merge,pC<= Established.Threshold2)
SNPs_establishedMethod2<-unique(helper2$rs1)


new2<-subset(last.result2,!is.element(last.result2$rs1,SNPs_establishedMethod2))
SNPs_newMethod_2<-unique(new2$rs1) # these are the index SNPs for which new secondary SNPs were found
hits2<-length(SNPs_newMethod_2)
cat("Dispersion parameter:",dispersion,".\n")
cat("Ingnored r2 in eucledian distance:",ignoreR2,".\n")
cat(length(unique(last.result2$rs1)),"regions with a conditional p smaller than final alpha threshold, assuming 5x10^-8 as standard.\n")
cat(hits2,"new regions found with new method, assuming 5x10^-8 as standard.\n")














































