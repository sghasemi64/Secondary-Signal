#This code is for iteration j

library(data.table)
#final1.tbl is meta analysis result file
#file1 is  individual-level genotype LD reference sample
#metal outputs are: MarkerName, Allele1, Allele2, Freq1, FreqSE,  MinFreq, MaxFreq, Effect, StdErr,  P-value, Direction, HetISq,  HetChiSq , HetDf,  HetPVal
#merge metal results with individual-level genotype LD reference sample to have position information


metal <- fread("final1.tbl", data.table=F)
Reference <- fread("file1.bim", data.table=F)
names(Reference) <-c("chr", "rsid", "pos.Morgan", "Position", "ale1","ale2")
merge <- merge(Reference , metal, by.x = "rsid", by.y = "MarkerName")
######################################################################################################################
#######################################################################################################################
#find significant SNPs between 22pre-defined SNPs
#Pvalue-result-22SNPs-sample-j is 22 pre-defined SNPs for iteration j in metal result file. 


Top <- fread("Pvalue-result-22SNPs-sample-j", data.table=F)

data <- merge(top22,Reference, by.x="MarkerName",by.y="rsid")
order <- data[order(data$chr),]
sig <- order[order$P.value < 5E-8,]

write.table(sig, "Top22.txt",sep="\t", row.names=F,col.names=F, quote=F)

##########################################################################################################################
##make 5MB sourrouning regions and select columns need for GCTA analysis (Columns are SNP, the effect allele, the other allele, frequency of the effect allele, effect size, standard error, p-value and sample size)
#SNPi.txt (i in 1:22) is input for --cojo-file parameter in GCTA analysis.
sample_size=n

for( i in chr){
  
  eval(parse(text=paste0("chr",i,"<- merge[merge$chr==",i,",]")))
  eval(parse(text=paste0("SNP",i,"<-chr",i,"[chr",i,"$Position<merge[merge$rsid==order[i,1],4]+2500000&chr",i,"$Position>=max(merge[merge$rsid==order[i,1],4]-2500000,0),c(2,7,8,9,13,14,15)]")))
  eval(parse(text=paste0("SNP",i,"$N<- sample_size")))
  eval(parse(text=paste0("write.table(SNP",i,",'SNP",i,".txt', sep='\t', row.names=F, quote=F)")))
}




















