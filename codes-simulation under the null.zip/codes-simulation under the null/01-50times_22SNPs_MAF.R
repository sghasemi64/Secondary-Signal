#selecting 50 times 22 SNPs with MAF > 0.1
library("data.table")
#SHIP-chri.assoc.dosage is a assosiation test file. PLINK output with header (SNP:rsID, A1:effect allele(risk allele), A2:uneffect allele, FRQ: frequancy of risk allele, ....) for autosome i (i=1..22)


for(i in 1:22){
    
  assign(paste0("data",i),fread(paste0("SHIP-chr",i,".assoc.dosage"),data.table=F))
  #randomly pick SNP with MAF > 0.1
  eval(parse(text=paste0("data",i,"<-data",i,"[sample(1:nrow(data",i,")),]" )))
  eval(parse(text=paste0("SN",i,"<-data",i,"[(data",i,"$FRQ<0.5&round(data",i,"$FRQ,2)>0.1)|(data",i,"$FRQ>0.5&round(1-data",i,"$FRQ,2)>0.1),c(1,4)]")))
  eval(parse(text=paste0("SNP",i,"<-SN",i,"[grep('rs',SN",i,"$SNP)",",]")))
}

SNPmaf<-matrix(rep(NA,50*22),ncol=50, nrow=22)

for(j in 1:50){
  for(i in 1:22){
    eval(parse(text=paste0("SNPmaf[",i,",",j,"]<-SNP",i,"[",j,",1]")))
  }
}

saveRDS(SNPmaf,file = "SNPmaf.rds")

