r2=0.3
wd=1 #wd=1 means step-wise-strong
k=5
#############################################################################################
#MERGE-interSNPS is intersnps results for all index SNPs.
#MERGE-GCTA is GCTA results for all index SNPs.
#########################################################################################
interSNPs <- read.table("MERGE-interSNPS", sep="",as.is=T, comment.char="")
GCTA <- read.table("MERGE-GCTA",header=TRUE, sep="",as.is=T, comment.char="")

colnames(GCTA) <- c("Chr","SNP","bp","refA","freq","b","se","p","n","freq_geno","bC","bC_se","pC")

interSNPs <- interSNPs[,c(1:8,17,18)]
names(interSNPs) <- c("chr","rs1","minorallele1","majorallele1","rs2","minorallele2","majorallele2","D","Dprime","R2")
#rs1=index SNP
#rs2=candidate SNP

data11 <- merge(interSNPs,GCTA,by.x ="rs2",by.y= "SNP")
data <- data11[-which(is.na(data11$pC)),]


#Assign pre-weight w_d
if (wd==1){
  data$w_d[abs(data$D) > 0 & abs(data$D) <= 1000] <- 1
  data$w_d[abs(data$D) > 1000 & abs(data$D) <= 10000] <- 0.5
  data$w_d[abs(data$D) > 10000 & abs(data$D) <= 50000] <- 0.25
  data$w_d[abs(data$D) > 50000 & abs(data$D) <= 100000] <- 0.125
  data$w_d[abs(data$D) > 100000 & abs(data$D) <= 500000] <- 0.0625
} else {
  data$w_d[abs(data$D) > 0 & abs(data$D) <= 1000] <- 1
  data$w_d[abs(data$D) > 1000 & abs(data$D) <= 10000] <- 0.8
  data$w_d[abs(data$D) > 10000 & abs(data$D) <= 50000] <- 0.6
  data$w_d[abs(data$D) > 50000 & abs(data$D) <= 100000] <- 0.4
  data$w_d[abs(data$D) > 100000 & abs(data$D) <= 500000] <- 0.2
}

#Assign pre-weight w_r
if (r2==0){
  data$w_r <- 1-data$R2
} else {
  data$w_r <- (1-abs(data$R2-0.3)-0.3)/(1-0.3)
}

#Combine w_d and w_r to get pre-weight w
data$equal <- sqrt(data$w_d*data$w_r)
data$mwd <- ((data$w_d^k)*data$w_r)^(1/(k+1))
data$mwr <- ((data$w_r^k)*data$w_d)^(1/(k+1))

m <- dim(data)[1]

S2 <- sum(data$mwd)
W2 <- (data$mwd*m)/S2

data$SNP_specifc_alpha_2 <- 1-(1-0.05)^{W2/m}

last.result2 <- data[data$pC <= data$SNP_specifc_alpha_2,]

####################################################################################################################################################

secondarysignal <- matrix(rep(NA,length(unique(last.result2[,"rs1"]))*dim(last.result2)[2]),length(unique(last.result2[,"rs1"])),dim(last.result2)[2])
colnames(secondarysignal) <- colnames(last.result2)
rownames(secondarysignal) <- c(unique(last.result2[,"rs1"]))
secondarysignal <- as.data.frame(secondarysignal)

secondarysignal_1 <- matrix(rep(NA,length(unique(last.result2[,"rs1"]))*dim(last.result2)[2]),length(unique(last.result2[,"rs1"])),dim(last.result2)[2])
colnames(secondarysignal_1) <- colnames(last.result2)
rownames(secondarysignal_1) <- c(unique(last.result2[,"rs1"]))
secondarysignal_1 <- as.data.frame(secondarysignal_1)

for (i in unique(last.result2[,"rs1"])){
  A <- last.result2[which(last.result2[,"rs1"]==i),]
  B <- A[which(A[,"pC"]==min(A[,"pC"])),]
  if (dim(B)[1]==1){secondarysignal[i,]<-A[which(A[,"pC"]==min(A[,"pC"])),]}
  {secondarysignal[i,] <-A[which(A[,"pC"]==min(A[,"pC"])),][1,] ; secondarysignal_1[i,] <-A[which(A[,"pC"]==min(A[,"pC"])),][2,]
  }
}

secondary_signal <- secondarysignal[order(secondarysignal$chr),c(2,1,3,8,10,22,29)]
secondary_signal_1 <- secondarysignal_1[order(secondarysignal_1$chr),c(2,1,3,8,10,22,29)]
write.table(secondary_signal,"secondary_signal.G5.txt", row.names=F, sep="\t", quote=F)
write.table(secondary_signal_1,"secondary_signal_1.G5.txt", row.names=F, sep="\t", quote=F)



Established.Threshold2 <- 5.00E-08
helper2<-subset(data,pC<= Established.Threshold2)
SNPs_establishedMethod2<-unique(helper2$rs1)


new2<-subset(last.result2,!is.element(last.result2$rs1,SNPs_establishedMethod2))
SNPs_newMethod_2<-unique(new2$rs1) # these are the index SNPs for which new secondary SNPs were found
hits2<-length(SNPs_newMethod_2)

cat("G5.\n")
cat("step-wise-strong-calibrated.\n")

cat(length(unique(last.result2$rs1)),"regions with a conditional p smaller than final alpha threshold, assuming 5x10^-8 as standard.\n")
cat(hits2,"new regions found with new method, assuming 5x10^-8 as standard.\n")



























