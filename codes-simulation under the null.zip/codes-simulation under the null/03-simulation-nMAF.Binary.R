
library(data.table)
#N=sample size, number of individuals
for (j in 1:50){
  data<-data.frame(matrix(c(1:N,rep(NA,N*22)),nrow =N))
  names(data)<-c(paste0("nMAFchr",1:22))
  for(i in 1:22){
    #read imputed genotypes for each SNP
    assign(paste0("chr",i,".",j),fread(paste0("chr",i,".",j),data.table=F))
    #remove SNPID, A1:effect allele(risk allele) and A2:uneffect allele and keep only the genotype propabilites for each individual
    eval(parse(text=paste0("chr",i,".",j,"<-chr",i,".",j,"[-c(1:3)]")))
    eval(parse(text=paste0("chr",i,".",j,"<-t(chr",i,".",j,")")))
    eval(parse(text=paste0("chr",i,".",j,"<-as.numeric(","chr",i,".",j,")")))
    #Compute the number of risk allele for each of the 22 selected SNPs for each individual and sum the results up
    for(k in -1:(N-2)){
      eval(parse(text=paste0("data[2+(",k,"),",i,"]<-chr",i,".",j,"[2*((",k,")+2)+(",k,")]*2+chr",i,".",j,"[2*((",k,")+2)+(",k,")+1]")))
    }}
  #) n is the number of risk alleles for each individual
  data$SUMnMAF <- rowSums(data[,], na.rm = FALSE,dims = 1)

  #binary trait  #########################################################################################################################
  #making 3 binary phenotypes for association test
  x <- rnorm(22,log(1.15),0.05)
  OR <- exp(x)
  data$f <- 0.01*((OR[1]^data$nMAFchr1)*(OR[2]^data$nMAFchr2)*(OR[3]^data$nMAFchr3)*(OR[4]^data$nMAFchr4)*(OR[5]^data$nMAFchr5)*(OR[6]^data$nMAFchr6)*
                    (OR[7]^data$nMAFchr7)*(OR[8]^data$nMAFchr8)*(OR[9]^data$nMAFchr9)*(OR[10]^data$nMAFchr10)*(OR[11]^data$nMAFchr11)*(OR[12]^data$nMAFchr12)*
                    (OR[13]^data$nMAFchr13)*(OR[14]^data$nMAFchr14)*(OR[15]^data$nMAFchr15)*(OR[16]^data$nMAFchr16)*(OR[17]^data$nMAFchr17)*(OR[18]^data$nMAFchr18)*
                    (OR[19]^data$nMAFchr19)*(OR[20]^data$nMAFchr20)*(OR[21]^data$nMAFchr21)*(OR[22]^data$nMAFchr22))
                    
  #random number x~U(0,1)
  data$runif1<-runif(nrow(data), min=0, max=1)
  data$runif2<-runif(nrow(data), min=0, max=1)
  data$runif3<-runif(nrow(data), min=0, max=1)
  
  #columns 28,29, and 30 are binary phenotypes for 3 GWAS
  data$phenotype1[data$runif1 < data$f]<-2
  data$phenotype2[data$runif2 < data$f]<-2
  data$phenotype3[data$runif3 < data$f]<-2
  data$phenotype1[data$runif1 > data$f]<-1
  data$phenotype2[data$runif2 > data$f]<-1
  data$phenotype3[data$runif3 > data$f]<-1
  
  eval(parse(text=paste0("write.table(data,'B-final-",j,".txt',sep='\t',row.names=F,quote=F)")))
}



